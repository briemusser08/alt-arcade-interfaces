

//Splash
//buttons
var twoPlayer
var vsBot

//PONG
//ball
var ballX; //x position
var ballY; //y position
var ballWidth = 15; 
var ballHeight = 15;
var ballSpeed = 2; //2 
var ballDirectionX = 1;// (1 right, -1 left)
var ballDirectionY = 1;// (1 down, -1 up)

//paddles
//player 1 IS CPU
var p1X = 5; // 10 away from left side
var p1Y = 250; // half of height
var cpuSpeed = 1.5; //change difficulty levels
//player 2
var p2X = 870; //10 from right
var p2Y = 250; //half of height
//sizes
var playerWidth = 25;
var playerHeight = 110;
//speed
var pSpeed =5; //adjust speed of paddle

//scoreboard
var p1Score = 0;
var p2Score = 0;

//Functions
var stage = 0; //0 = splash, 1 = pong, 2 = player 1 wins, 3= player 2 wins, etc.

//images
//let img;
var catPaw;
var catPaw2;
//sounds
var bounceSound;
var batSound;
var madSound;
var gladSound;

function preload(){
    //Sounds
  bounceSound = loadSound("cat_bell.mp3");
  batSound = loadSound("catbat.mp3");
  madSound = loadSound("screamcat.wav");
  gladSound = loadSound("happycat.wav");
  catPaw = loadImage("catpaw.png")
  catPaw2 = loadImage("catpaw2.png")
}

function setup() {
  createCanvas(900, 500);
  img = loadImage('Screenshot 2023-09-04 at 4.14.49 PM.png'); // Load the image
  
  //setting the ball into initial position
  rectMode(CENTER);
  circle(30, 30, 20);
  //finding half of canvas width and height and placing ball there
  ballX = width/2 
  ballY= height/2
  
  textAlign(CENTER);
  
}//close setup

function draw(){
// controls what stage /menu to pull up
  
  if (stage == 0){
    splash();
  }
  
  if (stage == 1){
    pong();
  }
  
  if (stage == 2){
    p1Wins();
  }
  
  if (stage == 3){
    p2Wins();
  }
  
  if(mouseIsPressed == true){
    stage=1;
  }
}//close draw

function splash(){
  background(225);
 
  
  textSize(150);
  fill(222, 49, 99);
  text ('Cat Pong', width/2, 300); //(text,x,y)
  
 /*  textSize(30);
  text ('Programmed by Brie Musser', width/2, 250); // (text,x,y)*/
  textSize(20);
  fill(0);
  text ('(Click to start)', width/2, 480); 
}//close splash

function p1Wins(){ //you lose
  background(222, 49, 99);
  fill(250);
  
  textSize(80);
  text ('TRY AGAIN', width/2, 300); //(text,x,y)
  fill(255);
  textSize(20);
  text ('(Refresh to replay)', width/2, 480); // (text,x,y)
  
}//close p1Wins

function p2Wins(){// you win
  background(80, 200, 120);
  fill(250);
  
  textSize(80);
  text ('WINNER', width/2, 300); //(text,x,y)
  fill(255);
  textSize(20);
  text ('(Refresh to replay)', width/2, 480); // (text,x,y)
  
}//close p2Wins

function pong() {
  // call functions
   keyTyped(); // loop keytyped function (allow holding button)
   /*keyPressed(); // loop keypressed function (allow holding button) */
  cpu();// call CPU
  
  //draws
  background (225); //black  
  noFill();
  stroke(225,120,160);// pink
  strokeWeight(5);
  rect (width/2, height/2, width, height);//outer border
  line(450, 0, 450, height);//center line
  
  //set colors 
  fill(255); //white
  noStroke();// no border
  
  
  //draw ball
  
  //rect(ballX, ballY, ballWidth, ballHeight);
 fill(222, 49, 99);//red laser
  circle(ballX, ballY, 20) // (x,y,diam)
  
  //color (225,0,0);
 

  //fill(255,200,150);
  //draw paddles
  //rect(p1X, p1Y, playerWidth, playerHeight);//draws player 1 paddle
  image(catPaw2, p1X, p1Y, playerWidth, playerHeight);
  image(catPaw, p2X, p2Y, playerWidth, playerHeight);//draws player 1 paddle
  
  //physics
  ballX = ballX + (ballDirectionX*ballSpeed); //moves ball horzontally
  ballY = ballY +(ballDirectionY*ballSpeed);
  
  //collisions
    //walls
    //bottom
    if (ballY >= height){ // we have hit bottom wall
      ballDirectionY = ballDirectionY * -1; // change direction of ball
      bounceSound.play();// play sound
    }
      //top
    if (ballY <= 0){ // we have hit top wall
      ballDirectionY = ballDirectionY * -1; // change direction of ball
      bounceSound.play();// play sound

    }
  
  //paddles
    //left
      if (ballX >= p1X && ballX <= p1X+24 && ballY >= p1Y-5 && ballY<= p1Y+110){ //has hit player1
        ballDirectionX = ballDirectionX*-1; //change  direction
        batSound.play();//play sound
      }
    //right
      if (ballX >= p2X && ballX <= p2X+24 && ballY >= p2Y-5 && ballY<= p2Y+110){ //has hit player2
           ballDirectionX = ballDirectionX*-1; //change  direction
        batSound.play(); //play sound
      }
  

//scoreboard
  fill(0);
  textSize(40);
  text(p1Score, 400, 45); // text of score (text, x,y)
  text(p2Score, 500, 45); // text of score (text, x,y)
  //p2 
  if(ballX <= 0){ //p1 missed
    p2Score = p2Score+1; //add point
    //ball goes center
    ballX = width/2;
    ballY = height/2;
    gladSound.play(); //play sound
  }
  //p1
   if(ballX >= width){ //p1 missed
    p1Score = p1Score+1; //add point
    //ball goes center
    ballX = width/2;
    ballY = height/2;
     madSound.play(); //play sound
  }
  
   if (p1Score >= 10){
    stage =2;
  }
  
  if (p2Score >= 10){
    stage =3;
  }

}//close pong


function keyTyped(){ // only works for letters and numbers
  if(key == 'w' && keyIsPressed){
    p2Y=p2Y-pSpeed; // makes it move up at speed 
  }//close w button
  
  if(key == 's' && keyIsPressed){
    p2Y=p2Y+pSpeed; // makes it move down at speed 
  }//close s button 
}

function cpu(){
  //controls CPU player
  if (ballX < width/2){//ball cross center line
    if (p1Y <= ballY){
    p1Y = p1Y + cpuSpeed;  //moves down
    }
    if (p1Y >= ballY){
    p1Y = p1Y - cpuSpeed;  //moves up
    }
  }
  else{
    p1Y = p1Y; //only move when ball is on CPU side
  }
}//close cpu

 /*function keyPressed(){
if (keyCode== UP_ARROW && keyIsPressed)
  p2Y=p2Y-pSpeed; // makes it move up at speed
  if (keyCode== DOWN_ARROW && keyIsPressed)
  p2Y=p2Y+pSpeed; // makes it move up at speed 
 } */
